<?php

/**
 * Test file for playlist functionality
 * This file tests the playlist filtering capabilities
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Test function to check playlist functionality
function test_playlist_functionality()
{
    echo "<h2>Testing Playlist Functionality</h2>";

    // Debug: Show all registered taxonomies
    $all_taxonomies = get_taxonomies();
    echo "<h3>Debug: All Registered Taxonomies</h3>";
    echo "<ul>";
    foreach ($all_taxonomies as $taxonomy) {
        $highlight = ($taxonomy === 'youtube_playlist') ? ' <strong>(TARGET)</strong>' : '';
        echo "<li>" . $taxonomy . $highlight . "</li>";
    }
    echo "</ul>";

    // Test 1: Check if taxonomy exists
    if (taxonomy_exists('youtube_playlist')) {
        echo "✅ YouTube Playlist taxonomy exists<br>";

        // Get taxonomy details
        $tax_object = get_taxonomy('youtube_playlist');
        if ($tax_object) {
            echo "- Taxonomy object types: " . implode(', ', $tax_object->object_type) . "<br>";
            echo "- Taxonomy public: " . ($tax_object->public ? 'Yes' : 'No') . "<br>";
            echo "- Taxonomy hierarchical: " . ($tax_object->hierarchical ? 'Yes' : 'No') . "<br>";
        }
    } else {
        echo "❌ YouTube Playlist taxonomy not found<br>";
        echo "🔍 This might indicate the taxonomy isn't registered yet or there's an issue with registration.<br>";
    }

    // Test 1b: Check if post type exists
    if (post_type_exists('youtube_short')) {
        echo "✅ YouTube Short post type exists<br>";
    } else {
        echo "❌ YouTube Short post type not found<br>";
    }

    // Test 2: Get all playlist terms
    $playlists = get_terms(array(
        'taxonomy' => 'youtube_playlist',
        'hide_empty' => false,
    ));

    if (is_wp_error($playlists)) {
        echo "❌ Error getting playlist terms: " . $playlists->get_error_message() . "<br>";
        echo "🔍 This usually means the taxonomy doesn't exist or isn't properly registered.<br>";
    } elseif (!empty($playlists) && is_array($playlists)) {
        echo "✅ Found " . count($playlists) . " playlist terms:<br>";
        foreach ($playlists as $playlist) {
            echo "- " . $playlist->name . " (slug: " . $playlist->slug . ")<br>";
        }
    } else {
        echo "⚠️ No playlist terms found (this is expected if no videos have been imported yet)<br>";
    }

    // Test 3: Check if posts exist
    $posts = get_posts(array(
        'post_type' => 'youtube_short',
        'numberposts' => 5,
        'post_status' => 'publish'
    ));

    if (!empty($posts)) {
        echo "✅ Found " . count($posts) . " YouTube Short posts<br>";

        // Test 4: Check if any posts have playlist associations
        $found_playlist_assignments = false;
        foreach ($posts as $post) {
            $playlists = wp_get_post_terms($post->ID, 'youtube_playlist');
            if (is_wp_error($playlists)) {
                echo "❌ Error getting playlists for post '" . $post->post_title . "': " . $playlists->get_error_message() . "<br>";
            } elseif (!empty($playlists) && is_array($playlists)) {
                echo "✅ Post '" . $post->post_title . "' is assigned to " . count($playlists) . " playlist(s)<br>";
                $found_playlist_assignments = true;
                break;
            }
        }
        if (!$found_playlist_assignments && !is_wp_error($playlists)) {
            echo "⚠️ No posts have playlist assignments yet<br>";
        }
    } else {
        echo "⚠️ No YouTube Short posts found (import videos first)<br>";
    }

    // Test 5: Test shortcode parsing
    echo "<h3>Testing Shortcode Examples:</h3>";

    $test_shortcodes = array(
        '[youtube_shorts playlist="test-playlist"]',
        '[youtube_shorts playlists="playlist1,playlist2"]',
        '[youtube_shorts exclude_playlist="private"]',
        '[youtube_shorts show_playlists="true"]'
    );

    foreach ($test_shortcodes as $shortcode) {
        echo "Shortcode: <code>" . esc_html($shortcode) . "</code><br>";
    }

    echo "<p><strong>To fully test playlist functionality:</strong></p>";
    echo "<ol>";
    echo "<li>Import videos from a channel that has playlists</li>";
    echo "<li>Check the YouTube Shorts admin page to see playlist columns</li>";
    echo "<li>Use shortcodes on a page/post to test filtering</li>";
    echo "</ol>";

    // Add manual fix buttons
    echo "<h3>🔧 Manual Fixes</h3>";
    echo '<p><a href="' . add_query_arg('force_register', '1') . '" class="button button-primary">Force Register Taxonomy</a></p>';
    echo '<p><a href="' . add_query_arg('flush_rules', '1') . '" class="button button-secondary">Flush Rewrite Rules</a></p>';
}

// Handle manual actions
add_action('admin_init', function () {
    if (current_user_can('manage_options')) {
        if (isset($_GET['force_register'])) {
            if (class_exists('EYSS_Post_Type')) {
                $post_type = new EYSS_Post_Type();
                add_action('admin_notices', function () {
                    echo '<div class="notice notice-success is-dismissible"><p>✅ Forced taxonomy registration!</p></div>';
                });
            }
        }

        if (isset($_GET['flush_rules'])) {
            flush_rewrite_rules();
            add_action('admin_notices', function () {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Flushed rewrite rules!</p></div>';
            });
        }
    }
});

// Add to WordPress admin for testing
add_action('admin_init', function () {
    if (isset($_GET['test_playlists']) && current_user_can('manage_options')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-info is-dismissible">';
            test_playlist_functionality();
            echo '</div>';
        });
    }
});

// Add playlist test to settings page when requested
add_action('admin_init', function () {
    if (
        isset($_GET['page']) && $_GET['page'] === 'embed-youtube-shorts' &&
        isset($_GET['playlist_test']) && current_user_can('manage_options')
    ) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-info is-dismissible" style="margin: 20px 0;">';
            echo '<h2>Playlist Functionality Test Results</h2>';
            test_playlist_functionality();
            echo '</div>';
        });
    }
});

// Test functionality is now accessible via settings page
