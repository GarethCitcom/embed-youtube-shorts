<?php

/**
 * Quick Playlist Test Page
 *
 * This creates a simple admin page to test playlist functionality
 * Access via: wp-admin/admin.php?page=playlist-quick-test
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Add admin page for quick testing
add_action('admin_menu', function () {
    add_management_page(
        'Playlist Quick Test',
        'Playlist Test',
        'manage_options',
        'playlist-quick-test',
        'eyss_playlist_quick_test_page'
    );
});

function eyss_playlist_quick_test_page()
{
?>
    <div class="wrap">
        <h1>YouTube Shorts - Playlist Quick Test</h1>

        <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc;">
            <?php eyss_run_playlist_tests(); ?>
        </div>

        <h2>Manual Actions</h2>
        <p><a href="<?php echo admin_url('admin.php?page=playlist-quick-test&action=flush_rewrite'); ?>" class="button button-secondary">Flush Rewrite Rules</a></p>
        <p><a href="<?php echo admin_url('admin.php?page=playlist-quick-test&action=register_taxonomy'); ?>" class="button button-secondary">Force Taxonomy Registration</a></p>

    </div>
<?php
}

function eyss_run_playlist_tests()
{
    // Handle manual actions
    if (isset($_GET['action'])) {
        switch ($_GET['action']) {
            case 'flush_rewrite':
                flush_rewrite_rules();
                echo '<div class="notice notice-success"><p>✅ Rewrite rules flushed!</p></div>';
                break;

            case 'register_taxonomy':
                if (class_exists('EYSS_Post_Type')) {
                    $post_type = new EYSS_Post_Type();
                    echo '<div class="notice notice-success"><p>✅ Post type and taxonomy registration forced!</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>❌ EYSS_Post_Type class not found!</p></div>';
                }
                break;
        }
    }

    echo "<h2>🔍 Diagnostic Information</h2>";

    // Test 1: WordPress Environment
    echo "<h3>WordPress Environment</h3>";
    echo "WordPress Version: " . get_bloginfo('version') . "<br>";
    echo "Active Theme: " . wp_get_theme()->get('Name') . "<br>";
    echo "WP_DEBUG: " . (defined('WP_DEBUG') && WP_DEBUG ? 'Enabled' : 'Disabled') . "<br>";

    // Test 2: Plugin Status
    echo "<h3>Plugin Status</h3>";
    if (class_exists('EmbedYouTubeShorts')) {
        echo "✅ Main plugin class loaded<br>";
    } else {
        echo "❌ Main plugin class NOT loaded<br>";
    }

    if (class_exists('EYSS_Post_Type')) {
        echo "✅ Post Type class loaded<br>";
    } else {
        echo "❌ Post Type class NOT loaded<br>";
    }

    // Test 3: Post Type and Taxonomy
    echo "<h3>Post Type & Taxonomy Status</h3>";

    if (post_type_exists('youtube_short')) {
        echo "✅ YouTube Short post type exists<br>";
        $post_type_obj = get_post_type_object('youtube_short');
        echo "- Post type public: " . ($post_type_obj->public ? 'Yes' : 'No') . "<br>";
    } else {
        echo "❌ YouTube Short post type NOT found<br>";
    }

    if (taxonomy_exists('youtube_playlist')) {
        echo "✅ YouTube Playlist taxonomy exists<br>";

        $tax_obj = get_taxonomy('youtube_playlist');
        echo "- Object types: " . implode(', ', $tax_obj->object_type) . "<br>";
        echo "- Public: " . ($tax_obj->public ? 'Yes' : 'No') . "<br>";
        echo "- Hierarchical: " . ($tax_obj->hierarchical ? 'Yes' : 'No') . "<br>";

        // Get terms
        $terms = get_terms(array(
            'taxonomy' => 'youtube_playlist',
            'hide_empty' => false
        ));

        if (!empty($terms)) {
            echo "- Found " . count($terms) . " playlist terms:<br>";
            foreach ($terms as $term) {
                echo "&nbsp;&nbsp;• " . $term->name . " (slug: " . $term->slug . ")<br>";
            }
        } else {
            echo "- No playlist terms found yet<br>";
        }
    } else {
        echo "❌ YouTube Playlist taxonomy NOT found<br>";
    }

    // Test 4: Posts
    echo "<h3>Content Status</h3>";
    $posts = get_posts(array(
        'post_type' => 'youtube_short',
        'numberposts' => 5,
        'post_status' => 'publish'
    ));

    if (!empty($posts)) {
        echo "✅ Found " . count($posts) . " YouTube Short posts<br>";

        foreach ($posts as $post) {
            $playlists = wp_get_post_terms($post->ID, 'youtube_playlist');
            if (!empty($playlists)) {
                echo "- '" . $post->post_title . "' has " . count($playlists) . " playlist(s)<br>";
            }
        }
    } else {
        echo "⚠️ No YouTube Short posts found<br>";
        echo "- Import some videos to see playlist associations<br>";
    }

    // Test 5: All Taxonomies (Debug)
    echo "<h3>All Registered Taxonomies (Debug)</h3>";
    $all_taxonomies = get_taxonomies(array(), 'objects');
    echo "<details><summary>Click to expand (" . count($all_taxonomies) . " total)</summary>";
    echo "<ul>";
    foreach ($all_taxonomies as $taxonomy => $tax_obj) {
        $highlight = ($taxonomy === 'youtube_playlist') ? ' <strong style="color: green;">(TARGET FOUND!)</strong>' : '';
        echo "<li>" . $taxonomy . " → " . implode(', ', $tax_obj->object_type) . $highlight . "</li>";
    }
    echo "</ul></details>";
}
