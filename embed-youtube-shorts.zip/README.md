# Embed YouTube Shorts Plugin

A comprehensive WordPress plugin that imports and displays YouTube Shorts using a custom post type system with playlist organization. Features advanced search, filtering, and multiple display layouts powered by the YouTube Data API v3.

## Features

### 🎥 Video Management
- **Custom Post Type**: YouTube Shorts are imported as WordPress posts (`youtube_short`)
- **Playlist Taxonomy**: Automatic playlist detection and organization using WordPress taxonomies
- **Smart Import System**: Detects and imports videos from channel playlists automatically
- **Automatic Cron Imports**: Optional daily auto-import with WordPress cron integration
- **Comprehensive Video Data**: Stores titles, descriptions, thumbnails, durations, view counts, and more
- **Local Storage**: All video data cached locally for fast loading and reduced API calls

### 🎨 Display & Layouts
- **Multiple Layouts**: Display videos in grid, carousel, or list layouts
- **Responsive Design**: Perfectly optimized for desktop, tablet, and mobile devices
- **Modal Viewer**: Full-screen video player with YouTube embed
- **Touch/Swipe Support**: Carousel navigation with touch gestures on mobile

### 🔍 Advanced Search & Filtering
- **Real-time Search**: Live search with client-side and AJAX functionality
- **Playlist Filtering**: Filter videos by specific playlists or multiple playlists
- **Search with Clear Button**: Easy search clearing and state management
- **Accurate Result Counts**: Shows total available videos, not just loaded count
- **Load More Support**: Choose between "Load More Button" or "Infinite Scroll" in admin settings
- **Infinite Scroll**: Automatic content loading when scrolling near bottom of videos

### ⚡ Performance & Caching
- **WordPress Integration**: Leverages WordPress post system for optimal performance
- **Smart Caching**: Reduced API calls through local post storage
- **Efficient Queries**: Uses WordPress query system for fast video retrieval
- **Load More Pagination**: Loads additional videos without page refresh

### 🛠 Developer Features
- **Shortcode System**: Powerful shortcode with extensive parameters
- **Taxonomy Support**: Uses WordPress taxonomy system for playlists
- **Admin Integration**: Full WordPress admin integration with post management
- **Debug Tools**: Built-in playlist testing and debugging functionality

## Installation & Setup

### 1. Install the Plugin
- Upload the `embed-youtube-shorts` folder to your `/wp-content/plugins/` directory
- Or install directly through the WordPress admin dashboard
- Activate the plugin via Plugins → Installed Plugins

### 2. Configure API Settings
- Go to **Settings → YouTube Shorts** in your WordPress admin
- Add your **YouTube Data API v3 key** (see API setup guide below)
- Add the **Channel ID** you want to import videos from
- Click **"Test Connection"** to verify your settings

### 3. Import Videos
- Once API is configured, click **"Import Videos"** in the settings page
- The plugin will automatically:
  - Fetch all videos from your channel
  - Filter for Shorts (videos under 60 seconds)
  - Detect playlist membership for each video
  - Create WordPress posts for each Short
  - Organize videos using the playlist taxonomy
- Progress is shown in real-time during import

### 3.1. Optional: Setup Automatic Imports
For hands-free video management:
- **Enable Auto-Import**: Check "Enable automatic daily video import" in settings
- **Set Import Time**: Choose when daily imports should run (server time)
- **Save Settings**: The plugin will automatically schedule daily imports
- **Benefits**: New videos are imported automatically without manual intervention

**Auto-Import Features:**
- 🔄 **Daily Sync**: Checks for new videos every 24 hours
- ⚡ **Light Import**: Only imports new videos from the last day for efficiency
- 📅 **Weekly Deep Sync**: Performs comprehensive import weekly to catch any missed videos
- 📝 **Automatic Logging**: All import activities logged for debugging
- 🛑 **Easy Control**: Can be enabled/disabled anytime from settings

### 4. Manage Content
After import, you can:
- **View Videos**: Go to **YouTube Shorts** in the admin menu
- **Manage Playlists**: Access playlist taxonomy via **YouTube Shorts → Playlists**
- **Test System**: Use the **"Test Playlists"** link on the settings page
- **Display Videos**: Use shortcodes on any page or post

### 5. Display Videos
Use the `[youtube_shorts]` shortcode anywhere in your content to display imported videos with full playlist filtering capabilities.

## Getting Your YouTube API Key

1. **Visit Google Cloud Console**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Sign in with your Google account

2. **Create or Select a Project**:
   - Create a new project or select an existing one
   - Make sure billing is enabled (required for API access)

3. **Enable YouTube Data API v3**:
   - In the Cloud Console, go to APIs & Services → Library
   - Search for "YouTube Data API v3"
   - Click on it and press "Enable"

4. **Create Credentials**:
   - Go to APIs & Services → Credentials
   - Click "Create Credentials" → "API Key"
   - Copy the generated API key
   - (Optional) Restrict the key to YouTube Data API v3 for security

5. **Add API Key to Plugin**:
   - In WordPress admin, go to Settings → YouTube Shorts
   - Paste your API key in the "YouTube API Key" field
   - Click "Test Connection" to verify it works

## Finding Your Channel ID

### Method 1: From Channel URL
If your channel URL looks like: `https://www.youtube.com/channel/UCxxxxxxxxxxxxxxxxxxxxx`
- The part after `/channel/` is your Channel ID (starts with UC)

### Method 2: From Custom URL
If your channel has a custom URL like: `https://www.youtube.com/@YourChannelName`
- You can use `@YourChannelName` as the Channel ID
- Or use online tools to convert it to the UC format

### Method 3: Using Browser Developer Tools
1. Go to your YouTube channel page
2. Right-click and select "View Page Source"
3. Search for "channelId" or "externalId"
4. Copy the value (should start with UC and be 24 characters long)

## Finding Your Playlist ID

### Method 1: From Playlist URL
If your playlist URL looks like: `https://www.youtube.com/playlist?list=PLxxxxxxxxxxxxxxxxxxxxx`
- The part after `list=` is your Playlist ID (starts with PL)

### Method 2: From YouTube Studio
1. Go to YouTube Studio
2. Navigate to "Content" → "Playlists"
3. Click on your playlist
4. The Playlist ID will be in the URL bar

### Method 3: From Any Playlist Page
1. Go to any YouTube playlist page
2. Look at the URL in your browser
3. Copy everything after `list=` (should start with PL and be about 34 characters long)

## Usage

### Basic Shortcode
```
[youtube_shorts]
```
Displays all imported YouTube Shorts using default settings.

### How It Works

The plugin uses a **two-phase approach**:

1. **Import Phase**: Videos are imported as WordPress posts with playlist taxonomy
2. **Display Phase**: Shortcodes query the local WordPress database for fast display

**Benefits of This Approach:**
- ⚡ **Lightning Fast**: No API calls during page load
- 🎯 **Advanced Filtering**: Use WordPress taxonomy system for playlist filtering
- 🔍 **Powerful Search**: Real-time search through imported video data
- 📊 **Scalable**: Handles large video collections efficiently
- 🛠 **Manageable**: Full WordPress admin integration

### Playlist Filtering

The plugin automatically detects playlist membership during import:

```
[youtube_shorts playlist="my-cooking-videos"]
```

**Supported Playlist Identifiers:**
- **YouTube Playlist ID**: `PLxxxxxxxxxxxxxxxxx` (from YouTube URLs)
- **Playlist Slug**: `my-cooking-videos` (WordPress-friendly version)
- **Playlist Name**: `Cooking Basics` (exact playlist title)

### Advanced Shortcode Examples
```
<!-- Show videos from specific playlist -->
[youtube_shorts playlist="cooking-basics" layout="grid" count="12"]

<!-- Multiple playlists -->
[youtube_shorts playlists="beginner,intermediate,advanced"]

<!-- Exclude certain playlists -->
[youtube_shorts exclude_playlist="private,drafts"]

<!-- Show playlist names on videos -->
[youtube_shorts show_playlists="true"]

<!-- Search-enabled grid -->
[youtube_shorts show_search="true" layout="grid"]
```

### Available Parameters

| Parameter | Options | Default | Description |
|-----------|---------|---------|-------------|
| **Display Settings** |
| `layout` | `grid`, `carousel`, `list` | From settings | Display layout |
| `count` | 1-50 | From settings | Number of videos to show initially |
| `autoplay` | `true`, `false` | `false` | Auto-play videos in modal |
| **Playlist Filtering** |
| `playlist` | Playlist identifier | None | Show videos from specific playlist |
| `playlists` | Comma-separated list | None | Show videos from multiple playlists |
| `exclude_playlist` | Playlist identifier | None | Exclude specific playlist |
| `exclude_playlists` | Comma-separated list | None | Exclude multiple playlists |
| `show_playlists` | `true`, `false` | `false` | Display playlist names on videos |
| **Display Options** |
| `show_title` | `true`, `false` | `true` | Show video titles |
| `show_duration` | `true`, `false` | `true` | Show video duration |
| `show_views` | `true`, `false` | `true` | Show view counts |
| `show_date` | `true`, `false` | `true` | Show upload date |
| **Search & Interaction** |
| `show_search` | `true`, `false` | `false` | Enable search functionality |
| `search_placeholder` | Text string | `Search videos...` | Search input placeholder text |
| `show_load_more` | `true`, `false` | `true` | Show load more button (behavior controlled by admin settings) |
| **Legacy Support** |
| `channel` | Channel ID | From settings | Filters by channel (for backwards compatibility) |

### Example Shortcodes

#### Basic Usage
```
<!-- All imported videos -->
[youtube_shorts]

<!-- Grid with search -->
[youtube_shorts layout="grid" show_search="true"]

<!-- Carousel with autoplay -->
[youtube_shorts layout="carousel" autoplay="true"]
```

#### Playlist Filtering
```
<!-- Single playlist by slug -->
[youtube_shorts playlist="cooking-tutorials"]

<!-- Single playlist by YouTube ID -->
[youtube_shorts playlist="PLxxxxxxxxxxxxxxxxx"]

<!-- Multiple playlists -->
[youtube_shorts playlists="beginner,intermediate,advanced"]

<!-- Exclude specific playlists -->
[youtube_shorts exclude_playlist="private,unlisted"]

<!-- Show playlist names on videos -->
[youtube_shorts playlist="featured" show_playlists="true"]
```

#### Advanced Examples
```
<!-- Complete featured section -->
[youtube_shorts
    playlist="featured"
    layout="carousel"
    count="8"
    show_playlists="true"
    autoplay="true"]

<!-- Searchable video library -->
[youtube_shorts
    layout="grid"
    show_search="true"
    search_placeholder="Search our video library..."
    count="20"]

<!-- Minimal video list -->
[youtube_shorts
    layout="list"
    exclude_playlists="private,drafts"
    show_views="false"
    show_date="false"]

<!-- Mobile-optimized carousel -->
[youtube_shorts
    layout="carousel"
    count="6"
    show_title="true"
    show_duration="true"]
```

## WordPress Integration

### Custom Post Type: `youtube_short`
Each imported video becomes a WordPress post with:
- **Post Title**: Video title from YouTube
- **Post Content**: Video description
- **Featured Image**: Video thumbnail
- **Custom Fields**: Duration, view count, like count, YouTube URL, etc.
- **Taxonomy**: Playlist assignments

### Admin Management
- **YouTube Shorts Menu**: Dedicated admin section for managing imported videos
- **Playlist Taxonomy**: Organized playlist management with WordPress taxonomy UI
- **Bulk Operations**: Edit, delete, or organize multiple videos at once
- **Standard WordPress Features**: Search, filtering, sorting in admin

### Playlist Taxonomy: `youtube_playlist`
- **Automatic Detection**: Playlists discovered during import
- **Hierarchical Support**: Nested playlist organization if needed
- **WordPress Integration**: Uses standard taxonomy management
- **Shortcode Filtering**: Filter videos by any playlist combination

## Display Layouts

### Grid Layout
- Responsive grid system (1-4 columns based on screen size)
- Perfect for showcasing multiple videos
- Hover effects and smooth transitions
- Search integration with real-time filtering

### Carousel Layout
- Horizontal scrolling with navigation arrows
- Touch/swipe support for mobile devices
- Automatic responsive adjustment
- Great for featured content sections

### List Layout
- Vertical layout with larger thumbnails
- Extended video information display
- Ideal for blog-style content
- Better for detailed video browsing

## Customization

### CSS Customization
You can override the plugin's styles by adding custom CSS to your theme:

```css
/* Customize grid spacing */
.eyss-videos-grid {
    gap: 30px;
}

/* Custom video item hover effect */
.eyss-video-item:hover {
    transform: scale(1.05);
}

/* Custom modal styling */
.eyss-modal-content {
    border-radius: 20px;
}
```

### Theme Integration
The plugin uses CSS classes that follow BEM methodology:
- `.eyss-container` - Main container
- `.eyss-video-item` - Individual video items
- `.eyss-videos-grid` - Grid layout container
- `.eyss-videos-carousel` - Carousel layout container
- `.eyss-videos-list` - List layout container

## Performance & Caching

The plugin includes built-in caching to improve performance:
- **API Response Caching**: YouTube API responses are cached to reduce API calls
- **Configurable Cache Duration**: Set cache duration in plugin settings
- **Automatic Cache Cleanup**: Expired cache entries are automatically removed
- **Minimal API Usage**: Only fetches Shorts (videos under 60 seconds)

### Automatic Import System
The plugin uses WordPress's built-in cron system for automatic imports:
- **WordPress Cron Integration**: Uses `wp_schedule_event()` for reliable scheduling
- **Smart Scheduling**: Automatically reschedules when settings change
- **Fail-safe Cleanup**: Removes scheduled tasks on plugin deactivation
- **Logging System**: All auto-import activities are logged to WordPress error log
- **Dual Import Strategy**:
  - Daily light sync (last 24 hours) for efficiency
  - Weekly comprehensive sync to ensure no videos are missed

## Troubleshooting

### Setup Issues

**"API key and Channel ID are required"**
- Ensure both API key and Channel ID are entered in Settings → YouTube Shorts
- Click "Test Connection" to verify API connectivity
- Check that your API key has YouTube Data API v3 enabled

**Import fails or no videos imported**
- Verify the channel has videos under 60 seconds (Shorts)
- Check that the Channel ID is correct (should start with UC)
- Ensure API key has sufficient quota remaining
- Look for error messages in the import progress display

**"No videos found" after successful import**
- Check **YouTube Shorts** admin menu to see if posts were created
- Verify shortcode is used correctly: `[youtube_shorts]`
- Check if videos were filtered out by playlist parameters

### Display Issues

**Shortcode shows no content**
- Confirm videos were imported successfully (check admin menu)
- Verify shortcode syntax is correct
- Check if playlist filtering is too restrictive
- Use `[youtube_shorts]` without parameters to test

**Playlist filtering not working**
- Go to **YouTube Shorts → Playlists** to see available playlists
- Use **Settings → Test Playlists** to verify playlist functionality
- Check playlist identifier spelling (slug, name, or YouTube ID)
- Ensure playlists were detected during import

**Search functionality not working**
- Check browser console for JavaScript errors
- Verify jQuery is loaded by your theme
- Clear browser cache and try again
- Test with `show_search="true"` parameter

**Modal not opening**
- Check browser console for JavaScript errors
- Ensure no conflicting modal plugins
- Verify theme compatibility with plugin JavaScript

### Performance Issues

**Slow page loading**
- Videos are loaded from local WordPress database (should be fast)
- Check if other plugins are causing conflicts
- Consider reducing `count` parameter in shortcodes
- Optimize images if using custom thumbnails

**"Load More" button not working**
- Check browser console for AJAX errors
- Verify WordPress AJAX is functioning properly
- Test with different `count` values
- Clear any caching plugins that might interfere

### Management Issues

**Cannot edit imported videos**
- Videos can be edited like regular WordPress posts
- Go to **YouTube Shorts** in admin menu
- Use standard WordPress bulk edit features
- Custom fields can be modified in post edit screen

**Auto-import not working**
- Check that "Enable automatic daily video import" is checked in settings
- Verify WordPress cron is functioning (some hosts disable it)
- Look for "EYSS Daily Import" entries in error logs
- Test by temporarily setting import time to a few minutes from now
- Ensure server time zone is configured correctly
- Consider using a plugin like "WP Crontrol" to monitor scheduled tasks

**Auto-import running at wrong time**
- Check your server's time zone settings
- The import time setting uses server time, not your local time
- You can verify current server time on the settings page
- Adjust the import time setting accordingly

### Getting Help

If you encounter issues:
1. Check the WordPress debug log for errors
2. Test with a default WordPress theme
3. Disable other plugins to check for conflicts
4. Verify your API key has the correct permissions
5. Make sure your website can make outbound HTTPS requests

## Requirements

- **WordPress**: 5.0 or higher
- **PHP**: 7.4 or higher
- **YouTube Data API v3 Key**: Required for fetching videos
- **Internet Connection**: Required for API calls
- **HTTPS**: Recommended for security

## Changelog

### Version 2.2.3 - Minor Formatting Fix
**🎨 Polish & Presentation**
- Fixed formatting in update notifications to display proper line breaks instead of literal \n characters
- Improved presentation of changelog and instructions in WordPress admin update interface

### Version 2.2.2 - Critical Search Fixes
**🐛 Critical Bug Fixes**
- Fixed search to properly filter within selected playlists instead of searching all videos
- Fixed total count restoration after clearing search (now shows original count, not loaded count)
- Enhanced data attribute passing for accurate playlist filtering in search
- Added support for all playlist filtering options (single, multiple, exclude) in search
- Improved search behavior to match user expectations with proper scoping

**🔧 Technical Improvements**
- Added missing playlist data attributes to shortcode container
- Enhanced JavaScript AJAX search parameters
- Updated PHP search method with comprehensive playlist filtering
- Fixed client-side search to store and restore original count properly

### Version 2.2.0 - Infinite Scroll Feature
**🚀 New Infinite Scroll Option**
- Added setting to choose between "Load More Button" and "Infinite Scroll"
- Automatic content loading when scrolling near the bottom
- Smooth scroll behavior with loading indicators
- Throttled scroll detection for optimal performance
- Seamless integration with existing load more functionality

**🎛 Enhanced Admin Settings**
- New "Load More Type" setting with radio button options
- Dynamic behavior based on user selection
- Clean UI integration in WordPress admin settings

**🔧 Technical Improvements**
- Proper data attribute handling for scroll type configuration
- JavaScript scroll listener optimization
- CSS animations for loading states
- Production-ready code with debugging support

### Version 2.0.0 - Major Architecture Overhaul
**🎯 Complete Custom Post Type Implementation**
- Videos now imported as WordPress posts (`youtube_short` custom post type)
- Local storage eliminates API calls during page display
- Full WordPress admin integration for video management

**📁 Playlist Taxonomy System**
- Automatic playlist detection during import
- WordPress taxonomy system for playlist organization (`youtube_playlist`)
- Advanced playlist filtering in shortcodes
- Support for multiple playlist inclusion/exclusion

**🔍 Enhanced Search & Filtering**
- Real-time search with client-side and AJAX functionality
- Search with clear button and proper state management
- Accurate result counts (total vs. loaded)
- Load more pagination with search integration

**⚡ Performance Improvements**
- Lightning-fast display (no API calls during page load)
- WordPress query optimization for large video collections
- Smart caching through local post storage
- Reduced API quota usage (import-once, display-many)

**🛠 Developer Enhancements**
- Comprehensive shortcode parameters for playlist filtering
- WordPress taxonomy integration for advanced queries
- Debug and testing tools integrated into settings page
- Backwards compatibility maintained

**🎨 UI/UX Improvements**
- Load more button with proper visibility management during search
- Enhanced modal video player
- Improved responsive design
- Better touch/swipe support for mobile

### Version 1.0.0 - Initial Release
- Basic grid, carousel, and list layouts
- Direct YouTube API integration
- Simple caching system
- Modal video player
- Basic shortcode functionality
- Admin settings page

## Support

For support and questions:
- Check the plugin documentation
- Review common troubleshooting steps
- Test with minimal configuration

## License

This plugin is licensed under the GPL v2 or later.

---

**Note**: This plugin requires a YouTube Data API v3 key from Google Cloud Console. API usage may be subject to quotas and billing depending on your usage and Google Cloud account settings.