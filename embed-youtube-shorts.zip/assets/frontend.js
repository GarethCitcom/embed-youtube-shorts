/**
 * Embed YouTube Shorts - Frontend JavaScript
 */

(function($) {
    'use strict';

    // Plugin namespace
    const EYSS = {

        /**
         * Initialize the plugin
         */
        init: function() {
            this.bindEvents();
            this.initializeCarousels();
            this.initializeSearch();
            this.initializeInfiniteScroll();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Video click handler
            $(document).on('click', '.eyss-video-item', this.handleVideoClick);

            // Modal close handlers
            $(document).on('click', '.eyss-modal-close', this.closeModal);
            $(document).on('click', '.eyss-modal', function(e) {
                if (e.target === this) {
                    EYSS.closeModal();
                }
            });

            // Escape key to close modal
            $(document).on('keydown', function(e) {
                if (e.keyCode === 27) { // Escape key
                    EYSS.closeModal();
                }
            });

            // Carousel navigation
            $(document).on('click', '.eyss-carousel-prev', this.handleCarouselPrev);
            $(document).on('click', '.eyss-carousel-next', this.handleCarouselNext);

            // Keyboard navigation for carousel
            $(document).on('keydown', '.eyss-carousel-nav', function(e) {
                if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
                    e.preventDefault();
                    $(this).click();
                }
            });

            // Handle window resize for carousel
            $(window).on('resize', this.debounce(this.handleCarouselResize, 250));

            // Load more functionality (if needed in the future)
            $(document).on('click', '.eyss-load-more', this.handleLoadMore);
        },

        /**
         * Initialize carousel functionality
         */
        initializeCarousels: function() {
            $('.eyss-layout-carousel').each(function() {
                const $carousel = $(this);
                EYSS.setupCarousel($carousel);
            });
        },

        /**
         * Setup individual carousel
         */
        setupCarousel: function($container) {
            const $carousel = $container.find('.eyss-carousel');
            const $videos = $carousel.find('.eyss-videos-carousel');
            const $prevBtn = $container.find('.eyss-carousel-prev');
            const $nextBtn = $container.find('.eyss-carousel-next');

            if (!$videos.length) return;

            // Initialize carousel state
            $carousel.data('current-index', 0);
            $carousel.data('items-per-view', this.getItemsPerView($container));
            $carousel.data('total-items', $videos.find('.eyss-video-item').length);

            // Update navigation buttons
            this.updateCarouselNavigation($container);

            // Touch/swipe support
            if ('ontouchstart' in window) {
                this.addTouchSupport($carousel);
            }
        },

        /**
         * Get number of items visible in carousel
         */
        getItemsPerView: function($container) {
            const containerWidth = $container.width();
            const itemWidth = 300; // 280px + 20px gap
            return Math.floor(containerWidth / itemWidth) || 1;
        },

        /**
         * Handle carousel previous button
         */
        handleCarouselPrev: function(e) {
            e.preventDefault();
            const $container = $(this).closest('.eyss-layout-carousel');
            const $carousel = $container.find('.eyss-carousel');
            const currentIndex = $carousel.data('current-index') || 0;
            const itemsPerView = $carousel.data('items-per-view') || 1;

            if (currentIndex > 0) {
                const newIndex = Math.max(0, currentIndex - itemsPerView);
                EYSS.moveCarousel($container, newIndex);
            }
        },

        /**
         * Handle carousel next button
         */
        handleCarouselNext: function(e) {
            e.preventDefault();
            const $container = $(this).closest('.eyss-layout-carousel');
            const $carousel = $container.find('.eyss-carousel');
            const currentIndex = $carousel.data('current-index') || 0;
            const itemsPerView = $carousel.data('items-per-view') || 1;
            const totalItems = $carousel.data('total-items') || 0;

            const maxIndex = Math.max(0, totalItems - itemsPerView);
            if (currentIndex < maxIndex) {
                const newIndex = Math.min(maxIndex, currentIndex + itemsPerView);
                EYSS.moveCarousel($container, newIndex);
            }
        },

        /**
         * Move carousel to specific index
         */
        moveCarousel: function($container, newIndex) {
            const $carousel = $container.find('.eyss-carousel');
            const $videos = $carousel.find('.eyss-videos-carousel');
            const itemWidth = 300; // 280px + 20px gap

            const translateX = -newIndex * itemWidth;
            $videos.css('transform', `translateX(${translateX}px)`);

            $carousel.data('current-index', newIndex);
            this.updateCarouselNavigation($container);
        },

        /**
         * Update carousel navigation button states
         */
        updateCarouselNavigation: function($container) {
            const $carousel = $container.find('.eyss-carousel');
            const $prevBtn = $container.find('.eyss-carousel-prev');
            const $nextBtn = $container.find('.eyss-carousel-next');

            const currentIndex = $carousel.data('current-index') || 0;
            const itemsPerView = $carousel.data('items-per-view') || 1;
            const totalItems = $carousel.data('total-items') || 0;

            // Update prev button
            $prevBtn.prop('disabled', currentIndex <= 0);

            // Update next button
            const maxIndex = Math.max(0, totalItems - itemsPerView);
            $nextBtn.prop('disabled', currentIndex >= maxIndex);
        },

        /**
         * Handle carousel resize
         */
        handleCarouselResize: function() {
            $('.eyss-layout-carousel').each(function() {
                const $container = $(this);
                const $carousel = $container.find('.eyss-carousel');
                const newItemsPerView = EYSS.getItemsPerView($container);

                $carousel.data('items-per-view', newItemsPerView);

                // Adjust current position if needed
                const currentIndex = $carousel.data('current-index') || 0;
                const totalItems = $carousel.data('total-items') || 0;
                const maxIndex = Math.max(0, totalItems - newItemsPerView);

                if (currentIndex > maxIndex) {
                    EYSS.moveCarousel($container, maxIndex);
                } else {
                    EYSS.updateCarouselNavigation($container);
                }
            });
        },

        /**
         * Add touch/swipe support for carousel
         */
        addTouchSupport: function($carousel) {
            let startX = 0;
            let startY = 0;
            let isDragging = false;

            $carousel.on('touchstart', function(e) {
                startX = e.touches[0].clientX;
                startY = e.touches[0].clientY;
                isDragging = false;
            });

            $carousel.on('touchmove', function(e) {
                if (!startX || !startY) return;

                const currentX = e.touches[0].clientX;
                const currentY = e.touches[0].clientY;

                const diffX = Math.abs(currentX - startX);
                const diffY = Math.abs(currentY - startY);

                if (diffX > diffY && diffX > 10) {
                    isDragging = true;
                    e.preventDefault(); // Prevent scrolling
                }
            });

            $carousel.on('touchend', function(e) {
                if (!isDragging || !startX) return;

                const endX = e.changedTouches[0].clientX;
                const diffX = startX - endX;
                const $container = $carousel.closest('.eyss-layout-carousel');

                if (Math.abs(diffX) > 50) { // Minimum swipe distance
                    if (diffX > 0) {
                        // Swiped left, go to next
                        $container.find('.eyss-carousel-next').click();
                    } else {
                        // Swiped right, go to previous
                        $container.find('.eyss-carousel-prev').click();
                    }
                }

                startX = 0;
                startY = 0;
                isDragging = false;
            });
        },

        /**
         * Handle video click
         */
        handleVideoClick: function(e) {
            e.preventDefault();
            e.stopPropagation();

            const $video = $(this);
            const videoId = $video.data('video-id');
            const $container = $video.closest('.eyss-container');
            const autoplay = $container.data('autoplay') === 1;

            if (!videoId) return;

            EYSS.openModal(videoId, autoplay);
        },

        /**
         * Open video modal
         */
        openModal: function(videoId, autoplay = false) {
            const $modal = $('#eyss-modal');
            const $iframe = $('#eyss-modal-iframe');

            // Create YouTube embed URL
            let embedUrl = `https://www.youtube.com/embed/${videoId}?`;
            const params = new URLSearchParams({
                'rel': '0',
                'modestbranding': '1',
                'fs': '1',
                'cc_load_policy': '0',
                'iv_load_policy': '3',
                'autohide': '0',
                'color': 'white',
                'theme': 'dark'
            });

            if (autoplay) {
                params.append('autoplay', '1');
            }

            embedUrl += params.toString();

            $iframe.attr('src', embedUrl);
            $modal.fadeIn(300);

            // Prevent body scroll
            $('body').addClass('eyss-modal-open');

            // Focus trap
            $modal.find('.eyss-modal-close').focus();
        },

        /**
         * Close video modal
         */
        closeModal: function() {
            const $modal = $('#eyss-modal');
            const $iframe = $('#eyss-modal-iframe');

            $modal.fadeOut(300, function() {
                $iframe.attr('src', '');
            });

            // Restore body scroll
            $('body').removeClass('eyss-modal-open');
        },

        /**
         * Handle load more videos
         */
        handleLoadMore: function(e) {
            e.preventDefault();

            const $button = $(this);
            const channelId = $button.data('channel') || '';
            const playlistId = $button.data('playlist') || '';
            const offset = parseInt($button.data('offset')) || 0;
            const count = parseInt($button.data('count')) || 12;
            const targetId = $button.data('target');
            const $container = $('#' + targetId);

            if ($button.hasClass('loading')) return;

            const originalText = $button.text();
            $button.addClass('loading').text('Loading...');

            $.ajax({
                url: eyss_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'eyss_load_more',
                    nonce: eyss_ajax.nonce,
                    channel_id: channelId,
                    playlist_id: playlistId,
                    offset: offset,
                    count: count
                },
                success: function(response) {
                    if (response.success) {
                        $container.find('.eyss-videos').append(response.data.html);

                        // Update button offset for next load
                        $button.data('offset', offset + count);

                        // Update search count if search is active
                        const $searchInput = $container.find('.eyss-search-input');
                        if ($searchInput.length && $searchInput.val()) {
                            // Reapply search filter to new items
                            EYSS.handleSearch.call($searchInput[0]);
                        } else {
                            // Update total count from server response
                            if (response.data.total_count) {
                                $container.find('.eyss-total-count').text(response.data.total_count);
                            } else {
                                // Fallback: count DOM elements
                                const newTotal = $container.find('.eyss-video-item').length;
                                $container.find('.eyss-total-count').text(newTotal);
                            }
                        }

                        if (!response.data.has_more) {
                            $button.fadeOut();
                        }
                    } else {
                        alert('Error loading more videos: ' + response.data);
                    }
                },
                error: function() {
                    alert('Error loading more videos. Please try again.');
                },
                complete: function() {
                    $button.removeClass('loading').text(originalText);
                }
            });
        },

        /**
         * Initialize infinite scroll functionality
         */
        initializeInfiniteScroll: function() {
            const self = this;

            // Find all containers with infinite scroll enabled
            const $containers = $('.eyss-container[data-scroll-type="infinite_scroll"]');

            $containers.each(function() {
                const $container = $(this);
                const $loadMoreBtn = $container.find('.eyss-load-more-btn');

                if ($loadMoreBtn.length) {
                    // Hide the load more button for infinite scroll
                    $loadMoreBtn.hide();

                    // Create scroll listener
                    self.setupInfiniteScrollListener($container, $loadMoreBtn);
                }
            });
        },

        /**
         * Setup infinite scroll listener for a container
         */
        setupInfiniteScrollListener: function($container, $loadMoreBtn) {
            const self = this;
            let isLoading = false;
            let throttleTimeout;

            // Throttled scroll handler
            function onScroll() {
                if (throttleTimeout) clearTimeout(throttleTimeout);

                throttleTimeout = setTimeout(function() {
                    if (isLoading) return;

                    const containerBottom = $container.offset().top + $container.outerHeight();
                    const viewportBottom = $(window).scrollTop() + $(window).height();
                    const threshold = 200; // Trigger 200px before reaching bottom

                    if (viewportBottom + threshold >= containerBottom) {
                        isLoading = true;

                        // Show loading indicator
                        self.showInfiniteScrollLoader($container);

                        // Trigger load more
                        self.loadMoreForInfiniteScroll($loadMoreBtn, function() {
                            isLoading = false;
                            self.hideInfiniteScrollLoader($container);
                        });
                    }
                }, 100);
            }

            $(window).on('scroll', onScroll);

            // Also check on resize
            $(window).on('resize', onScroll);
        },        /**
         * Load more videos for infinite scroll
         */
        loadMoreForInfiniteScroll: function($loadMoreBtn, callback) {
            const channelId = $loadMoreBtn.data('channel') || '';
            const playlistId = $loadMoreBtn.data('playlist') || '';
            const offset = parseInt($loadMoreBtn.data('offset')) || 0;
            const count = parseInt($loadMoreBtn.data('count')) || 12;
            const targetId = $loadMoreBtn.data('target');
            const $container = $('#' + targetId);            $.ajax({
                url: eyss_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'eyss_load_more',
                    nonce: eyss_ajax.nonce,
                    channel_id: channelId,
                    playlist_id: playlistId,
                    offset: offset,
                    count: count
                },
                success: function(response) {
                    if (response.success) {
                        $container.find('.eyss-videos').append(response.data.html);

                        // Update button offset for next load
                        $loadMoreBtn.data('offset', offset + count);

                        // Update search count if search is active
                        const $searchInput = $container.find('.eyss-search-input');
                        if ($searchInput.length && $searchInput.val()) {
                            // Reapply search filter to new items
                            EYSS.handleSearch.call($searchInput[0]);
                        } else if (response.data.total_count !== undefined) {
                            const $totalCount = $container.find('.eyss-total-count');
                            if ($totalCount.length) {
                                $totalCount.text(response.data.total_count);
                            }
                        }

                        // Hide load more button if no more videos
                        if (response.data.has_more === false) {
                            $loadMoreBtn.hide();
                            // Remove scroll listener when no more content
                            $(window).off('scroll');
                        }
                    }
                },
                complete: function() {
                    callback();
                }
            });
        },

        /**
         * Show infinite scroll loading indicator
         */
        showInfiniteScrollLoader: function($container) {
            if (!$container.find('.eyss-infinite-loader').length) {
                const loader = $('<div class="eyss-infinite-loader" style="text-align: center; padding: 20px; font-size: 14px; color: #666;"><span>Loading more videos...</span></div>');
                $container.append(loader);
            }
        },

        /**
         * Hide infinite scroll loading indicator
         */
        hideInfiniteScrollLoader: function($container) {
            $container.find('.eyss-infinite-loader').remove();
        },

        /**
         * Initialize search functionality
         */
        initializeSearch: function() {
            // Bind keyup event for search inputs
            $(document).on('keyup input', '.eyss-search-input', this.debounce(this.handleSearch, 300));

            // Show/hide clear button based on input content
            $(document).on('input', '.eyss-search-input', this.toggleClearButton);

            // Bind click event for clear button
            $(document).on('click', '.eyss-search-clear', this.clearSearch);

            // Bind click event for load more buttons
            $(document).on('click', '.eyss-load-more-btn', this.handleLoadMore);
        },

        /**
         * Handle search functionality
         */
        handleSearch: function() {
            const $input = $(this);
            const searchTerm = $input.val().toLowerCase().trim();
            const targetId = $input.data('target');
            const $container = $('#' + targetId);

            // Handle completely empty search - same as clear button
            if (searchTerm === '') {
                EYSS.handleEmptySearch($container);
                return;
            }

            // For better performance with large datasets, use both client-side and server-side search
            if (searchTerm.length >= 3) {
                // Use AJAX search for terms 3+ characters for better accuracy
                EYSS.performAjaxSearch($input, searchTerm, $container);
            } else {
                // Use client-side filtering for short terms
                EYSS.performClientSearch($input, searchTerm, $container);
            }
        },

        /**
         * Perform client-side search (for short terms or when no server search needed)
         */
        performClientSearch: function($input, searchTerm, $container) {
            // Store original count if not already stored
            if (!$container.data('original-count')) {
                $container.data('original-count', $container.find('.eyss-total-count').text());
            }

            const $videoItems = $container.find('.eyss-video-item');
            let visibleCount = 0;

            // Note: Empty search is handled by handleEmptySearch function
            // Filter videos by title
            $videoItems.each(function() {
                const $item = $(this);
                const videoTitle = $item.data('video-title') || '';

                if (videoTitle.includes(searchTerm)) {
                    $item.show();
                    visibleCount++;
                } else {
                    $item.hide();
                }
            });

            // Show/hide no results message
            if (visibleCount === 0) {
                $container.find('.eyss-no-results').show();
            } else {
                $container.find('.eyss-no-results').hide();
            }

            // Hide load more button during client-side search (filtered results don't support pagination)
            const $loadMoreContainer = $container.find('.eyss-load-more-container');
            if ($loadMoreContainer.length && !$container.data('original-load-more-state')) {
                $container.data('original-load-more-state', $loadMoreContainer.is(':visible'));
            }
            $loadMoreContainer.hide();

            // This is client-side filtering, not AJAX replacement
            $container.data('search-performed', false);

            // Update total count display
            $container.find('.eyss-total-count').text(visibleCount);

            // Update carousel if needed
            if ($container.hasClass('eyss-layout-carousel')) {
                EYSS.updateCarouselAfterSearch($container);
            }
        },

        /**
         * Perform AJAX-based search for more accurate results
         */
        performAjaxSearch: function($input, searchTerm, $container) {
            // Store original content if not already stored
            if (!$container.data('original-content')) {
                $container.data('original-content', $container.find('.eyss-videos').html());
                $container.data('original-count', $container.find('.eyss-total-count').text());
            }

            // Show loading state
            $container.find('.eyss-videos').addClass('eyss-loading');

            // Extract search parameters from container data or input data
            const channelId = $container.data('channel') || '';
            const playlistId = $container.data('playlist') || '';
            const playlists = $container.data('playlists') || '';
            const excludePlaylist = $container.data('exclude-playlist') || '';
            const layout = $container.data('layout') || 'grid';

            $.ajax({
                url: eyss_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'eyss_search_videos',
                    nonce: eyss_ajax.nonce,
                    search: searchTerm,
                    channel_id: channelId,
                    playlist_id: playlistId,
                    playlists: playlists,
                    exclude_playlist: excludePlaylist,
                    layout: layout,
                    count: 50 // Search more results
                },
                success: function(response) {
                    if (response.success) {
                        // Mark that search was performed
                        $container.data('search-performed', true);

                        // Replace video grid with search results
                        $container.find('.eyss-videos').html(response.data.html);
                        $container.find('.eyss-total-count').text(response.data.count);

                        // Hide load more button during search (search results are complete)
                        const $loadMoreContainer = $container.find('.eyss-load-more-container');
                        if ($loadMoreContainer.length && !$container.data('original-load-more-state')) {
                            $container.data('original-load-more-state', $loadMoreContainer.is(':visible'));
                        }
                        $loadMoreContainer.hide();

                        if (response.data.count === 0) {
                            $container.find('.eyss-no-results').show();
                        } else {
                            $container.find('.eyss-no-results').hide();
                        }

                        // Update carousel if needed
                        if ($container.hasClass('eyss-layout-carousel')) {
                            EYSS.updateCarouselAfterSearch($container);
                        }
                    } else {
                        // Fallback to client-side search
                        EYSS.performClientSearch($input, searchTerm, $container);
                    }
                },
                error: function() {
                    // Fallback to client-side search
                    EYSS.performClientSearch($input, searchTerm, $container);
                },
                complete: function() {
                    $container.find('.eyss-videos').removeClass('eyss-loading');
                }
            });
        },

        /**
         * Handle empty search (when user deletes all text)
         */
        handleEmptySearch: function($container) {
            // Check if we need to reload original content via AJAX
            if ($container.data('search-performed')) {
                // Reload original videos
                EYSS.reloadOriginalVideos($container);
            } else {
                // Just show all currently loaded videos
                $container.find('.eyss-video-item').show();
                $container.find('.eyss-no-results').hide();

                // Restore load more button state
                const originalLoadMoreState = $container.data('original-load-more-state');
                if (originalLoadMoreState !== undefined) {
                    const $loadMoreContainer = $container.find('.eyss-load-more-container');
                    if (originalLoadMoreState) {
                        $loadMoreContainer.show();
                    } else {
                        $loadMoreContainer.hide();
                    }
                }

                // Update counts - restore original count if available
                const originalCount = $container.data('original-count');
                if (originalCount) {
                    $container.find('.eyss-total-count').text(originalCount);
                } else {
                    // Fallback to current loaded items if original count not stored
                    const totalItems = $container.find('.eyss-video-item').length;
                    $container.find('.eyss-total-count').text(totalItems);
                }

                // Update carousel if needed
                if ($container.hasClass('eyss-layout-carousel')) {
                    EYSS.updateCarouselAfterSearch($container);
                }
            }
        },

        /**
         * Reload original videos (before search)
         */
        reloadOriginalVideos: function($container) {
            const originalContent = $container.data('original-content');
            const originalCount = $container.data('original-count');

            if (originalContent) {
                // Restore original content
                $container.find('.eyss-videos').html(originalContent);
                $container.find('.eyss-total-count').text(originalCount);
                $container.find('.eyss-no-results').hide();

                // Restore load more button state
                const originalLoadMoreState = $container.data('original-load-more-state');
                if (originalLoadMoreState !== undefined) {
                    const $loadMoreContainer = $container.find('.eyss-load-more-container');
                    if (originalLoadMoreState) {
                        $loadMoreContainer.show();
                    } else {
                        $loadMoreContainer.hide();
                    }
                }

                // Clear search performed flag
                $container.data('search-performed', false);

                // Update carousel if needed
                if ($container.hasClass('eyss-layout-carousel')) {
                    EYSS.setupCarousel($container);
                }
            } else {
                // Fallback: reload page content via AJAX
                location.reload();
            }
        },        /**
         * Update carousel after search filtering
         */
        updateCarouselAfterSearch: function($container) {
            const $carousel = $container.find('.eyss-carousel');
            const $visibleItems = $container.find('.eyss-video-item:visible');
            const totalVisible = $visibleItems.length;
            const itemsPerView = this.getItemsPerView($container);

            // Update carousel data
            $carousel.data('total-items', totalVisible);
            $carousel.data('current-index', 0);

            // Reset carousel position
            $carousel.css('transform', 'translateX(0)');

            // Update navigation
            this.updateCarouselNavigation($container);
        },

        /**
         * Toggle clear button visibility
         */
        toggleClearButton: function() {
            const $input = $(this);
            const $clearButton = $input.siblings('.eyss-search-clear');

            if ($input.val().trim()) {
                $clearButton.show();
            } else {
                $clearButton.hide();
            }
        },

        /**
         * Clear search input and reset results
         */
        clearSearch: function(e) {
            e.preventDefault();

            const $button = $(this);
            const $input = $button.siblings('.eyss-search-input');
            const targetId = $input.data('target');
            const $container = $('#' + targetId);

            // Clear input
            $input.val('');

            // Hide clear button
            $button.hide();

            // Check if we need to reload original content via AJAX
            if ($container.data('search-performed')) {
                // Reload original videos via AJAX
                EYSS.reloadOriginalVideos($container);
            } else {
                // Just show all currently loaded videos
                $container.find('.eyss-video-item').show();
                $container.find('.eyss-no-results').hide();

                // Restore load more button state
                const originalLoadMoreState = $container.data('original-load-more-state');
                if (originalLoadMoreState !== undefined) {
                    const $loadMoreContainer = $container.find('.eyss-load-more-container');
                    if (originalLoadMoreState) {
                        $loadMoreContainer.show();
                    } else {
                        $loadMoreContainer.hide();
                    }
                }

                // Update counts
                const totalItems = $container.find('.eyss-video-item').length;
                $container.find('.eyss-total-count').text(totalItems);

                // Update carousel if needed
                if ($container.hasClass('eyss-layout-carousel')) {
                    EYSS.updateCarouselAfterSearch($container);
                }
            }

            // Focus back to input
            $input.focus();
        },        /**
         * Debounce function
         */
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func.apply(this, args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        EYSS.init();
    });

    // Add CSS class to body when modal is open (for scroll prevention)
    $(document).ready(function() {
        $('<style>')
            .prop('type', 'text/css')
            .html(`
                .eyss-modal-open {
                    overflow: hidden;
                }
            `)
            .appendTo('head');
    });

})(jQuery);